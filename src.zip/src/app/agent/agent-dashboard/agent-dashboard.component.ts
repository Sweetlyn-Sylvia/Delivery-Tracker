import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { AgentService } from '../../services/agent.service';

@Component({
  selector: 'app-agent-dashboard',
  templateUrl: './agent-dashboard.component.html',
  styleUrls: ['./agent-dashboard.component.scss']
})
export class AgentDashboardComponent implements OnInit {

  Highcharts: typeof Highcharts = Highcharts;

  chartOptions: Highcharts.Options = {

    chart: { type: 'pie' },

    title: { text: 'Today Parcel Activity' },

    series: [{
      type: 'pie',
      name: 'Parcels',
      data: [

        { name: 'Picked Up', y: 0, color: '#FF9800' },
        { name: 'In Transit', y: 0, color: '#9C27B0' },
        { name: 'Delivered', y: 0, color: '#4CAF50' }
      ]
    }]

  };

  agentName = '';
  agentID = '';

  stats = {
    createdToday: 0,
    pickedUpToday: 0,
    inTransitToday: 0,
    deliveredToday: 0
  };

  navLinks = [
    { label: 'Book Parcel', route: '/book-parcel' },
    { label: 'View Parcels', route: '/view-parcel' },
    { label: 'Update Status', route: '/update-status' }
  ];

  constructor(private agentService: AgentService) {}

  ngOnInit(): void {

    this.agentName = localStorage.getItem('agentName') || 'Agent';
    this.agentID = localStorage.getItem('agentID') || '';

    this.loadDashboard();
  }

  loadDashboard() {

    this.agentService.getDashboard(this.agentID)
      .subscribe((data: any) => {

        this.stats = data;

        this.chartOptions = {
          ...this.chartOptions,
          series: [{
            type: 'pie',
            name: 'Parcels',
            data: [

              { name: 'Picked Up', y: this.stats.pickedUpToday, color: '#593ef6' },
              { name: 'In Transit', y: this.stats.inTransitToday, color: '#142b31' },
              { name: 'Delivered', y: this.stats.deliveredToday, color: '#56c5d9' }
            ]
          }]
        };

      });

  }

  logout() {

    localStorage.removeItem('agentID');
    localStorage.removeItem('agentName');

    window.location.href = '/agent-login';

  }

}
