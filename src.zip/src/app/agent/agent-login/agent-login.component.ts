import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AgentService } from '../../services/agent.service';

@Component({
  selector: 'app-agent-login',
  templateUrl: './agent-login.component.html',
  styleUrls: ['./agent-login.component.scss']
})
export class AgentLoginComponent {

  agent = {
    email: '',
    password: ''
  };
  navLinks = [
    { label: 'Home', route: '/' },
    { label: 'Supervisor Portal', route: '/supervisor-login' }
  ];


  showPopup = false;
  popupMessage = '';

  constructor(private agentService: AgentService, private router: Router) {}

  onLogin() {

    this.agentService.login(this.agent).subscribe({

      next: (res:any) => {
        this.popupMessage = `${res.message}`;
        this.showPopup = true;



  if(res.message === "Agent logged in successfully"){

    localStorage.setItem('agentID', res.agentId);
    localStorage.setItem('agentName', res.agentName);
   

    setTimeout(() => {
      this.router.navigate(['/agent-dashboard']);
    }, 1500);

  }
},


 error: (err) => {
  if (err.error) {
    this.popupMessage = err.error;
  } else {
    this.popupMessage = "Login failed. Please try again.";
  }
  this.showPopup = true;
}

    });

  }

  closePopup(){
    this.showPopup = false;
    this.popupMessage = '';
    this.agent = {
      email: '',
      password: ''
    };

  }

}
