import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
     
import { AgentService } from '../../services/agent.service';
import { AgentSignup } from '../../models/agent-signup';

@Component({
  selector: 'app-agent-signup',
  templateUrl: './agent-signup.component.html',
  styleUrls: ['./agent-signup.component.scss']
})
export class AgentSignupComponent {

  agent: AgentSignup = {
    agentName: '',
    email: '',
    phone: '',
    password: ''
  };

  confirmPassword = '';

  navLinks = [
    { label: 'Home', route: '/' },
    { label: 'Supervisor Portal', route: '/supervisor-login' }
  ];

  showPopup = false;
  popupMessage = '';

  constructor(private agentService: AgentService) {}

  onSubmit(signupForm: NgForm) {

    if (this.agent.password !== this.confirmPassword) {
      this.popupMessage = "Passwords do not match";
      this.showPopup = true;
      return;
    }

    this.agentService.signup(this.agent).subscribe({

      next: (res) => {

        this.popupMessage = `${res.message}`;
        this.showPopup = true;

        this.agent = {
          agentName: '',
          email: '',
          phone: '',
          password: ''
        };

        this.confirmPassword = '';

        signupForm.resetForm();
      },

      error: (err) => {
  if (err.error) {
    this.popupMessage = err.error;
  } else {
    this.popupMessage = "Signup failed. Please try again.";
  }
  this.showPopup = true;
}

    });

  }

  closePopup() {
    this.showPopup = false;
    this.popupMessage = '';

    this.agent = {
      agentName: '',
      email: '',
      phone: '',
      password: ''
    };

    this.confirmPassword = '';
  }

}
