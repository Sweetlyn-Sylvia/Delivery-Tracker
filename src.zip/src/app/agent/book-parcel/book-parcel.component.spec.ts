import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookParcelComponent } from './book-parcel.component';

describe('BookParcelComponent', () => {
  let component: BookParcelComponent;
  let fixture: ComponentFixture<BookParcelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BookParcelComponent]
    });
    fixture = TestBed.createComponent(BookParcelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
