import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ParcelService } from '../../services/parcel.service';
import * as QRCode from 'qrcode';

@Component({
  selector: 'app-book-parcel',
  templateUrl: './book-parcel.component.html',
  styleUrls: ['./book-parcel.component.scss']
})
export class BookParcelComponent {

parcel = {
  SenderName: '',
  ReceiverName: '',
  SenderAddress: '',
  ReceiverAddress: '',
  ReceiverContactNumber: '',
  Weight: null as any
};

navLinks = [
  {label: 'Dashboard', route: '/agent-dashboard'},
  {label: 'View Parcels', route: '/view-parcel'},
  {label: 'Update Status', route: '/update-status'}
];

agentID = localStorage.getItem('agentID') || '';
currentDate = new Date().toLocaleString();

baseRatePerKg = 50;
fastDeliveryCharge = 200;

deliveryAmount = 0;
fastDelivery = false;
paymentMode = '';
isPaid = false;

upiPaymentURL = '';
qrImage = '';

showPopup = false;
popupMessage = '';

constructor(
  private parcelService: ParcelService,
  private router: Router
) {}

calculateAmount(){

  if(!this.parcel.Weight || this.parcel.Weight <= 0){
    this.deliveryAmount = 0;
    return;
  }

  this.deliveryAmount = this.parcel.Weight * this.baseRatePerKg;

  if(this.fastDelivery){
    this.deliveryAmount += this.fastDeliveryCharge;
  }

  this.upiPaymentURL =
  `upi://pay?pa=sweetlynsylvia@oksbi&pn=Shipzo&am=${this.deliveryAmount}&cu=INR`;

  this.generateQR();
}

generateQR(){

  if(!this.upiPaymentURL) return;

  QRCode.toDataURL(this.upiPaymentURL)
  .then(url=>{
    this.qrImage = url;
  })
  .catch(err=>console.error(err));

}

onSubmit(parcelForm:any){

  if(!this.agentID){
    this.popupMessage = "Agent not logged in";
    this.showPopup = true;
    return;
  }

  if(!this.paymentMode || !this.isPaid){
    this.popupMessage = "Complete payment first";
    this.showPopup = true;
    return;
  }

  const parcelData = {
    ...this.parcel,
    AgentId: this.agentID,
    DeliveryAmount: this.deliveryAmount,
    FastDelivery: this.fastDelivery,
    PaymentMode: this.paymentMode,
    IsPaid: this.isPaid
  };

  this.parcelService.bookParcel(parcelData).subscribe({

    next:(res:any)=>{

      this.popupMessage =
      `Parcel Created Successfully\nParcel ID: ${res.parcelId}`;

      this.showPopup = true;

      parcelForm.resetForm();
      this.resetPayment();
    },

    error:(err)=>{

      if(err.error){
        this.popupMessage = err.error;
      }else{
        this.popupMessage = "Error creating parcel";
      }

      this.showPopup = true;
    }

  });

}

closePopup(){
  this.showPopup = false;
  this.popupMessage = '';
}

resetPayment(){
  this.deliveryAmount = 0;
  this.fastDelivery = false;
  this.paymentMode = '';
  this.isPaid = false;
  this.qrImage = '';
  this.upiPaymentURL = '';
}



}
