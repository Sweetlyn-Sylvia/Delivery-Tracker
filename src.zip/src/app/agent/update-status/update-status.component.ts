import { Component, OnInit } from '@angular/core';
import { ParcelService } from '../../services/parcel.service';

@Component({
  selector: 'app-update-status',
  templateUrl: './update-status.component.html',
  styleUrls: ['./update-status.component.scss']
})
export class UpdateStatusComponent implements OnInit {

  parcels: any[] = [];
  filteredParcels: any[] = [];

  agentID: string = localStorage.getItem('agentID') || '';

  statusFilter: string = 'ALL';
  searchParcelId: string = '';
  fastDeliveryOnly: boolean = false;

  showRemarksPopup = false;
  showLocationPopup = false;

  selectedParcelID = '';
  remarksText = '';

  locationText = '';
  locationLat: number | null = null;
  locationLng: number | null = null;

  popupMessage = '';
  showPopup = false;

  navLinks = [
    { label: 'Dashboard', route: '/agent-dashboard' },
    { label: 'Book Parcel', route: '/book-parcel' },
    { label: 'View Parcels', route: '/view-parcel' }
  ];

  constructor(private parcelService: ParcelService) {}

  ngOnInit(): void {
    this.loadParcels();
  }

  loadParcels() {

    this.parcelService.getParcelsByAgent(this.agentID).subscribe({
      next: (res: any) => {

        this.parcels = res.map((p: any) => ({
          ...p,
          parcelID: p.parcelID || p.ParcelId || p.parcelId,
          status: p.status || p.Status
        }));

        this.applyFilters();
      },
      error: (err) => {
        console.error("Error loading parcels", err);
      }
    });

  }

  applyFilters() {

    this.filteredParcels = this.parcels.filter(p => {

      const parcelId = (p.parcelID || '').toString().toLowerCase();
      const search = (this.searchParcelId || '').toLowerCase();

      if (p.status === 'Delivered') return false;

      const matchesStatus =
        this.statusFilter === 'ALL'
          ? p.status !== 'Delivered'
          : p.status === this.statusFilter;

      const matchesParcelId = parcelId.includes(search);

      const matchesFast =
        !this.fastDeliveryOnly || p.deliveryType === 'Fast Delivery';

      return matchesStatus && matchesParcelId && matchesFast;
    });

  }

  setStatusFilter(status: string) {
    this.statusFilter = status;
    this.applyFilters();
  }

  toggleFastDelivery() {
    this.fastDeliveryOnly = !this.fastDeliveryOnly;
    this.applyFilters();
  }

  updateStatus(parcel: any) {

    const parcelID = parcel.parcelID;
    const newStatus = parcel.status;

    if (newStatus === 'Delivered') {
      this.selectedParcelID = parcelID;
      this.showRemarksPopup = true;
      return;
    }

    if (newStatus === 'In Transit') {
      this.selectedParcelID = parcelID;
      this.showLocationPopup = true;
      return;
    }

    this.parcelService.updateParcelStatus(parcelID, {
      status: newStatus,
      remarks: ""
    }).subscribe({
      next: () => {
        this.showSuccess("Status updated successfully");
        this.loadParcels();
      },
      error: () => {
        this.showSuccess("Error updating status");
      }
    });
  }

  getCurrentLocation() {

    if (!navigator.geolocation) {
      this.showSuccess("Geolocation not supported on this device");
      return;
    }

    navigator.geolocation.getCurrentPosition(

      (position) => {

        this.locationLat = position.coords.latitude;
        this.locationLng = position.coords.longitude;

        this.showSuccess(
          "Location detected: " +
          this.locationLat.toFixed(4) +
          ", " +
          this.locationLng.toFixed(4)
        );

      },

      (error) => {

        if (error.code === 1)
          this.showSuccess("Location permission denied");

        else if (error.code === 2)
          this.showSuccess("Location unavailable");

        else
          this.showSuccess("Unable to fetch location");

      },

      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }

    );
  }

  submitLocation() {

    const payload = {
      lat: this.locationLat ?? 0,
      lng: this.locationLng ?? 0,
      locationText: this.locationText
    };

    this.parcelService.updateParcelStatus(this.selectedParcelID, {
      status: "In Transit",
      remarks: ""
    }).subscribe(() => {

      this.parcelService.updateParcelLocation(this.selectedParcelID, payload)
        .subscribe({
          next: () => {

            this.showSuccess("Location updated successfully");

            this.closeLocationPopup();
            this.loadParcels();

          },
          error: () => {
            this.showSuccess("Error updating location");
          }
        });

    });
  }

  submitRemarks() {

    this.parcelService.updateParcelStatus(this.selectedParcelID, {
      status: "Delivered",
      remarks: this.remarksText
    }).subscribe({
      next: () => {

        this.showSuccess("Parcel delivered successfully");

        this.closeRemarksPopup();
        this.loadParcels();

      },
      error: () => {
        this.showSuccess("Error updating delivery status");
      }
    });
  }

  closeRemarksPopup() {
    this.showRemarksPopup = false;
    this.remarksText = '';
  }

  closeLocationPopup() {
    this.showLocationPopup = false;
    this.locationText = '';
    this.locationLat = null;
    this.locationLng = null;
  }

  showSuccess(msg: string) {
    this.popupMessage = msg;
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
  }

}
