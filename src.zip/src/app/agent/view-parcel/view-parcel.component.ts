import { Component, OnInit } from '@angular/core';
import { ParcelService } from '../../services/parcel.service';
import { ParcelDetails } from '../../models/parcel-details';
import { TrackParcel } from 'src/app/models/track-parcel';
import { RouteService } from '../../services/route.service';

@Component({
  selector: 'app-view-parcel',
  templateUrl: './view-parcel.component.html',
  styleUrls: ['./view-parcel.component.scss']
})
export class ViewParcelComponent implements OnInit {

  parcels: ParcelDetails[] = [];
  allParcels: ParcelDetails[] = [];

  selectedStatus: string = 'All';
  agentId: string = '';

  showRoutePopup = false;
  agentLocationText = '';
  agentLat = 0;
  agentLng = 0;

  optimizedParcels: any[] = [];

  messagePopup = false;
  popupMessage = '';

  constructor(
    private parcelService: ParcelService,
    private routeService: RouteService
  ) {}

  ngOnInit(): void {
    this.agentId = localStorage.getItem('agentID') || '';
    this.loadParcels();
  }

  navLinks = [
    { label: 'Dashboard', route: '/agent-dashboard' },
    { label: 'Book Parcel', route: '/book-parcel' },
    { label: 'Update Status', route: '/update-status' }
  ];

  loadParcels(): void {
    this.parcelService.getParcelsByAgent(this.agentId).subscribe({
      next: (res) => {
        this.allParcels = res;
        this.applyFilter();
      },
      error: (err) => {
        console.error('Error fetching parcels', err);
      }
    });
  }

  applyFilter(): void {
    if (this.selectedStatus === 'All') {
      this.parcels = this.allParcels;
    } else {
      this.parcels = this.allParcels.filter(
        p => p.status === this.selectedStatus
      );
    }
  }

 openRoutePopup() {
  this.showRoutePopup = true;


  this.optimizedParcels = [];
  this.agentLocationText = '';
  this.agentLat = 0;
  this.agentLng = 0;
}
  useGPS() {
    this.agentLocationText = '';
    navigator.geolocation.getCurrentPosition(pos => {
      this.agentLat = pos.coords.latitude;
      this.agentLng = pos.coords.longitude;
    });
  }


optimizeRoute() {


  this.optimizedParcels = [];


  if (this.agentLocationText && this.agentLocationText.trim() !== '') {

    this.parcelService.getCoordinates(this.agentLocationText.trim())
      .subscribe(res => {

        if (!res || res.length === 0) {
          this.popupMessage = "Location not found. Please enter a valid place.";
          this.messagePopup = true;
          return;
        }


        this.agentLat = parseFloat(res[0].lat);
        this.agentLng = parseFloat(res[0].lon);

        this.prepareParcels();

      },
      error => {
        this.popupMessage = "Error fetching location. Try again.";
        this.messagePopup = true;
      });

  }

  else if (this.agentLat !== 0 && this.agentLng !== 0) {

    this.prepareParcels();

  }

  else {
    this.popupMessage = "Please enter a location or use GPS.";
    this.messagePopup = true;
  }
}

  prepareParcels() {

    const activeParcels = this.allParcels.filter(p =>
      p.status === 'Picked Up' || p.status === 'In Transit'
    );

    if (activeParcels.length === 0) {
      this.popupMessage = "No active parcels (Picked Up / In Transit) available.";
      this.messagePopup = true;
      return;
    }

    let completed = 0;
    const enrichedParcels: any[] = [];

    activeParcels.forEach(p => {


      this.parcelService.trackParcel(p.parcelId)
        .subscribe((track: TrackParcel) => {


          if (track && track.currentLat && track.currentLng) {

            enrichedParcels.push({
              ...p,
              currentLat: track.currentLat,
              currentLng: track.currentLng
            });

            completed++;
            if (completed === activeParcels.length) {
              this.finalOptimize(enrichedParcels);
            }

          } else {


            this.parcelService.getCoordinates(p.receiverAddress)
              .subscribe(res => {

                if (res.length > 0) {
                  enrichedParcels.push({
                    ...p,
                    currentLat: parseFloat(res[0].lat),
                    currentLng: parseFloat(res[0].lon)
                  });
                }

                completed++;
                if (completed === activeParcels.length) {
                  this.finalOptimize(enrichedParcels);
                }
              });
          }

        });

    });
  }

  finalOptimize(parcels: any[]) {

    this.optimizedParcels = this.routeService.optimizeRoute(
      this.agentLat,
      this.agentLng,
      parcels
    );

    if (this.optimizedParcels.length === 0) {
      this.popupMessage = "Unable to calculate distances.";
      this.messagePopup = true;
      return;
    }

    this.showRoutePopup = false;
  }
}
