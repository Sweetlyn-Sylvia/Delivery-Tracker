import { ProfileComponent } from './supervisor/profile/profile.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AgentSignupComponent } from './agent/agent-signup/agent-signup.component';
import { AgentLoginComponent } from './agent/agent-login/agent-login.component';
import { AgentDashboardComponent } from './agent/agent-dashboard/agent-dashboard.component';
import { BookParcelComponent } from './agent/book-parcel/book-parcel.component';
import { UpdateStatusComponent } from './agent/update-status/update-status.component';
import { ViewParcelComponent } from './agent/view-parcel/view-parcel.component';
import { SupervisorLoginComponent } from './supervisor/supervisor-login/supervisor-login.component';
import { SupervisorDashboardComponent } from './supervisor/supervisor-dashboard/supervisor-dashboard.component';
import { ParcelManagementComponent } from './supervisor/parcel-management/parcel-management.component';
import { ReportGenerationComponent } from './supervisor/report-generation/report-generation.component';

import {AgentPerformanceComponent} from './supervisor/agent-performance/agent-performance.component';

import { agentAuthGuard } from './guards/agent-guard.guard';
import { supervisorAuthGuard } from './guards/supervisor-guard.guard';

const routes: Routes = [
  { path: '', component: HomeComponent },
  {path:'agent-signup', component: AgentSignupComponent},
  {path:'agent-login', component: AgentLoginComponent},
  {path:'agent-dashboard', component: AgentDashboardComponent, canActivate: [agentAuthGuard]},
  {path:'book-parcel', component: BookParcelComponent, canActivate: [agentAuthGuard]},
  {path:'update-status', component: UpdateStatusComponent, canActivate: [agentAuthGuard]},
  {path:'view-parcel', component: ViewParcelComponent, canActivate: [agentAuthGuard]},
  {path:'supervisor-login', component: SupervisorLoginComponent},
  {path:'supervisor-dashboard', component: SupervisorDashboardComponent, canActivate: [supervisorAuthGuard]},
  {path:'parcel-management', component: ParcelManagementComponent, canActivate: [supervisorAuthGuard]},
  {path:'report-generation', component: ReportGenerationComponent, canActivate: [supervisorAuthGuard]},
  {path:'supervisor-profile',component:ProfileComponent, canActivate: [supervisorAuthGuard]},
  {path:'agent-performance',component:AgentPerformanceComponent, canActivate: [supervisorAuthGuard]}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
