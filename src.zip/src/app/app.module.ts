import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AgentSignupComponent } from './agent/agent-signup/agent-signup.component';
import { AgentLoginComponent } from './agent/agent-login/agent-login.component';
import { AgentDashboardComponent } from './agent/agent-dashboard/agent-dashboard.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { BookParcelComponent } from './agent/book-parcel/book-parcel.component';
import { UpdateStatusComponent } from './agent/update-status/update-status.component';
import { ViewParcelComponent } from './agent/view-parcel/view-parcel.component';
import { SupervisorLoginComponent } from './supervisor/supervisor-login/supervisor-login.component';
import { SupervisorDashboardComponent } from './supervisor/supervisor-dashboard/supervisor-dashboard.component';

import { ParcelManagementComponent } from './supervisor/parcel-management/parcel-management.component';
import { ReportGenerationComponent } from './supervisor/report-generation/report-generation.component';
import { ProfileComponent } from './supervisor/profile/profile.component';
import { AgentPerformanceComponent } from './supervisor/agent-performance/agent-performance.component';



@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    AgentSignupComponent,
    AgentLoginComponent,
    AgentDashboardComponent,
    BookParcelComponent,
    UpdateStatusComponent,
    ViewParcelComponent,
    SupervisorLoginComponent,
    SupervisorDashboardComponent,
    ParcelManagementComponent,
    ReportGenerationComponent,
    ProfileComponent,
    AgentPerformanceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    HighchartsChartModule,
    CommonModule
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
