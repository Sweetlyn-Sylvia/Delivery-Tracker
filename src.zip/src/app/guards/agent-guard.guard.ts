import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const agentAuthGuard: CanActivateFn = () => {

  const router = inject(Router);

  const agentId = localStorage.getItem('agentID');

  if(agentId){
    return true;
  }

  router.navigate(['/agent-login']);
  return false;

};
