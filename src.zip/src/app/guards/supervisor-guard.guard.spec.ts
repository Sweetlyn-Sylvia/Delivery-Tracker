import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { supervisorGuardGuard } from './supervisor-guard.guard';

describe('supervisorGuardGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => supervisorGuardGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
