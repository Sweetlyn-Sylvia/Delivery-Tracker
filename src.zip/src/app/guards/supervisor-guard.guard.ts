import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const supervisorAuthGuard: CanActivateFn = () => {

  const router = inject(Router);

  const supervisorId = localStorage.getItem('supervisorID');

  if(supervisorId){
    return true;
  }

  router.navigate(['/supervisor-login']);
  return false;

};
