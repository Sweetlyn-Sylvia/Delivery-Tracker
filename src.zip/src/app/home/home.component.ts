import { Component } from '@angular/core';
import { ParcelService } from '../services/parcel.service';
import { TrackParcel } from '../models/track-parcel';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  parcelID = '';
  loading = false;
  errorMessage = '';
  showPopup = false;

  parcelData!: TrackParcel;

  navLinks = [
    { label: 'Home', route: '/' },
    { label: 'Agent Portal', route: '/agent-signup' },
    { label: 'Supervisor Portal', route: '/supervisor-login' }
  ];

  constructor(private parcelService: ParcelService) {}

  trackPackage() {

    if (!this.parcelID) {
      this.errorMessage = 'Please enter Parcel ID';
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    this.parcelService.trackParcel(this.parcelID).subscribe({

      next: (data) => {
        this.parcelData = data;
        this.showPopup = true;
        this.loading = false;
      },

      error: () => {
        this.errorMessage = 'Parcel not found';
        this.loading = false;
      }

    });

  }

  closePopup() {
    this.showPopup = false;
    this.parcelID = '';
    this.parcelData = {} as TrackParcel;
    this.errorMessage = '';
  }

}
