export interface AgentPerformance {
  agentId: string;
  name: string;
  delivered: number;
  inTransit: number;
  pickedUp: number;
}