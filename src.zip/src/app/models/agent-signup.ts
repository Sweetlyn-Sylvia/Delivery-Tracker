export interface AgentSignup {
  agentName: string;
  email: string;
  phone: string;
  password: string;
}
