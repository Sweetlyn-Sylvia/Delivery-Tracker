export interface ParcelDetails {
  parcelId: string;
  senderName: string;
  receiverName: string;
  senderAddress: string;
  receiverAddress: string;
  receiverContactNumber: string;
  weight: number;
  status: string;
  agentId: string;
  date: Date;
  remarks: string;
  deliveryAmount: number;
  deliveryType: string;
}
