export interface ParcelResponse {
  message: string;
  parcelId: string;
}