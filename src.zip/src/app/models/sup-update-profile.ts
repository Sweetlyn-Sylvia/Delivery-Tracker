export interface UpdateProfileRequest {
  supervisorId: string;
  name: string;
  email: string;
  phone: string;
  currentPassword?: string;
  newPassword?: string;
}
