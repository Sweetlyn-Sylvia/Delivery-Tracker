export interface SupervisorLoginResponse {
  message: string;
}
export interface SupervisorLogin {
  SupervisorId: string;
  Password: string;
}
export interface DashboardSummary {
  totalParcels: number;
  deliveredParcels: number;
  inTransitParcels: number;
  pickedUpParccels: number;
  totalAgents: number;
  todaysEarning: number;
}

export interface NotificationResponse {
  parcelId: string;
  status: string;
  agentID?: string;
  agentName: string;
  type: string;
  message: string;
}

export interface AssignAgent {
  parcelId: string;
  agentId: string;
}
export interface Agent {
  agentId: string;
  agentName: string;
}
