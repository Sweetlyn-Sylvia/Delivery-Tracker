export interface Supervisor {
  supervisorId: string;
  name: string;
  email: string;
  phone: string;
}
