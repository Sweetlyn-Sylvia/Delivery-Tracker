export interface TrackParcel {
  parcelId: string;
  status: string;
  receiverAddress: string;
  currentLat?: number;
  currentLng?: number;
  currentLocationText?: string;
  locationUpdatedAt?: string;
}
