import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {

  @Input() navLinks: { label: string; route: string }[] = [];

  @Input() showLogout: boolean = false;

  @Output() logoutClicked = new EventEmitter<void>();

  logout() {
    this.logoutClicked.emit();
  }

}
