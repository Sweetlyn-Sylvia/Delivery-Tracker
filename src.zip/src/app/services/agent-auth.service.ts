import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AgentAuthService {

  constructor(private router: Router) {}

  isLoggedIn(): boolean {

    const agentId = localStorage.getItem('agentID');

    return agentId !== null;

  }

  logout() {

    localStorage.removeItem('agentID');
    localStorage.removeItem('agentName');

    this.router.navigate(['/agent-login']);

  }

}
