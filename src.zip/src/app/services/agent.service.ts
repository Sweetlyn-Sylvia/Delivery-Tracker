import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AgentSignup } from '../models/agent-signup';
import { environment } from '../../environments/environment';
import { AgentPerformance } from '../models/agent-performance';
export interface MessageResponse {
  message: string;
}

@Injectable({
  providedIn: 'root'
})

export class AgentService {

  private apiUrl = `${environment.apiUrl}/Agent`;

  constructor(private http: HttpClient) {}

signup(agent: AgentSignup): Observable<any> {
  return this.http.post(`${this.apiUrl}/register`, agent);
}
 login(agent: any) {
  return this.http.post<any>(`${this.apiUrl}/login`, agent);
}
  getDashboard(agentId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/dashboard/${agentId}`);
  }
  getAgentPerformance(){
    return this.http.get<AgentPerformance[]>(`${this.apiUrl}/performance`);
  }
  deleteAgent(agentId: string){
    return this.http.delete<MessageResponse>(`${this.apiUrl}/${agentId}`);
  }



}
