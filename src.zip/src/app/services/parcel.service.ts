import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TrackParcel } from '../models/track-parcel';
import { ParcelDetails } from '../models/parcel-details';
import { environment } from '../../environments/environment';
import { ParcelResponse } from '../models/parcel-response';


@Injectable({
  providedIn: 'root'
})
export class ParcelService {

  private apiUrl = `${environment.apiUrl}/Parcel`;

  constructor(private http: HttpClient) {}

  trackParcel(parcelId: string): Observable<TrackParcel> {
    return this.http.get<TrackParcel>(`${this.apiUrl}/track/${parcelId}`);
  }
    bookParcel(parcel: any): Observable<ParcelResponse> {
    return this.http.post<ParcelResponse>(`${this.apiUrl}/create`, parcel);
  }
  getAllParcels(): Observable<ParcelDetails[]> {
    return this.http.get<ParcelDetails[]>(`${this.apiUrl}/all`);
  }
   getParcelById(parcelId: string): Observable<ParcelDetails> {
    return this.http.get<ParcelDetails>(`${this.apiUrl}/${parcelId}`);
  }
    updateParcelStatus(parcelId: string, data: any) {
    return this.http.put(`${this.apiUrl}/update-status/${parcelId}`, data);
  }
  getParcelsByAgent(agentId: string): Observable<ParcelDetails[]> {
  return this.http.get<ParcelDetails[]>(`${this.apiUrl}/parcel-agent/${agentId}`);
}
  filterParcels(filters: {
  status?: string;
  agentId?: string;
  date?: string;
}): Observable<ParcelDetails[]> {

  return this.http.get<ParcelDetails[]>(`${this.apiUrl}/filter`, {
    params: filters
  });

}

  updateParcelLocation(parcelId: string, data: any) {
    return this.http.put(`${this.apiUrl}/update-location/${parcelId}`, data);
  }
  getCoordinates(address:string){
return this.http.get<any>(
`https://nominatim.openstreetmap.org/search?q=${address}&format=json&limit=1`
);
  }
 



}
