import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

 private apiUrl = `${environment.apiUrl}/Reports`;
  constructor(private http: HttpClient) {}
  getDailyReport() {
    return this.http.get(`${this.apiUrl}/daily`, { responseType: 'blob' });
  }

  getDeliveredReport() {
    return this.http.get(`${this.apiUrl}/delivered`, { responseType: 'blob' });
  }

  getPendingReport() {
    return this.http.get(`${this.apiUrl}/pending`, { responseType: 'blob' });
  }

  getRangeReport(startDate: string, endDate: string) {
    return this.http.get(
      `${this.apiUrl}/range?startDate=${startDate}&endDate=${endDate}`,
      { responseType: 'blob' }
    );
  }

  getAgentReport(agentId: string) {
    return this.http.get(
      `${this.apiUrl}/agent?agentId=${agentId}`,
      { responseType: 'blob' }
    );
  }
}
