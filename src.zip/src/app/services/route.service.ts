import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RouteService {

  private toRad(value: number): number {
    return value * Math.PI / 180;
  }

  calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {

    if (
      lat1 == null || lon1 == null ||
      lat2 == null || lon2 == null ||
      isNaN(lat1) || isNaN(lon1) ||
      isNaN(lat2) || isNaN(lon2)
    ) {
      return 0;
    }

    const R = 6371;

    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);

    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) *
      Math.cos(this.toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  }

  optimizeRoute(agentLat: number, agentLng: number, parcels: any[]) {

   
    const activeParcels = parcels.filter(p =>
      p.status === 'Picked Up' || p.status === 'In Transit'
    );


    const result = activeParcels
      .map(p => {

        const lat = Number(p.currentLat);
        const lng = Number(p.currentLng);

        const distance = this.calculateDistance(
          agentLat,
          agentLng,
          lat,
          lng
        );

        return {
          parcelId: p.parcelId,
          receiverAddress: p.receiverAddress,
          distance: distance
        };
      })


      .filter(p => p.distance > 0)


      .sort((a, b) => a.distance - b.distance);

    return result;
  }
}
