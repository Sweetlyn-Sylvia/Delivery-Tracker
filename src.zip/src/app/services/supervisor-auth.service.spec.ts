import { TestBed } from '@angular/core/testing';

import { SupervisorAuthService } from './supervisor-auth.service';

describe('SupervisorAuthService', () => {
  let service: SupervisorAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SupervisorAuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
