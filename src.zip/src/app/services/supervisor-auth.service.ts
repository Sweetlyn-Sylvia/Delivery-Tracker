import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SupervisorAuthService {

  constructor(private router: Router) {}

  isLoggedIn(): boolean {

    const supervisorId = localStorage.getItem('supervisorID');

    return supervisorId !== null;

  }

  logout() {

    localStorage.removeItem('supervisorID');
    localStorage.removeItem('supervisorData');

    this.router.navigate(['/supervisor-login']);

  }

}
