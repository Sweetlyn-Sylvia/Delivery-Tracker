import { MessageResponse } from './../models/profile-response';
import { SupervisorLoginResponse } from './../models/supervisor-login';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { DashboardSummary } from './../models/supervisor-login';
import { NotificationResponse } from './../models/supervisor-login';
import { AssignAgent } from './../models/supervisor-login';
import { Agent } from './../models/supervisor-login';
import { Supervisor } from '../models/supervisor';
import { UpdateProfileRequest } from '../models/sup-update-profile';



@Injectable({
  providedIn: 'root'
})
export class SupervisorService {

 private apiUrl = `${environment.apiUrl}/Supervisor`;
  constructor(private http: HttpClient) {}

  login(data: any): Observable<SupervisorLoginResponse> {
    return this.http.post<SupervisorLoginResponse>(`${this.apiUrl}/login`, data);
  }
  getDashboardSummary(): Observable<DashboardSummary> {
    return this.http.get<DashboardSummary>(`${this.apiUrl}/dashboard-summary`);
  }


  getNotifications(): Observable<NotificationResponse[]> {
    return this.http.get<NotificationResponse[]>(`${this.apiUrl}/notifications`);
  }


  getAgents(): Observable<Agent[]> {
    return this.http.get<Agent[]>(`${environment.apiUrl}/Agent`);
  }

  sendReminder(data: AssignAgent): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.apiUrl}/send-reminder`, data);
  }


  assignAgent(data: AssignAgent): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.apiUrl}/assign-agent`, data);
  }
  getSupervisorById(id: string): Observable<any> {
  return this.http.get<any>(`${this.apiUrl}/${id}`);
}
 getProfile(supervisorId: string): Observable<Supervisor> {
    return this.http.get<Supervisor>(`${this.apiUrl}/${supervisorId}`);
  }
    updateProfile(data: UpdateProfileRequest): Observable<MessageResponse> {
    return this.http.put<MessageResponse>(`${this.apiUrl}/update-profile`, data);
  }



}
