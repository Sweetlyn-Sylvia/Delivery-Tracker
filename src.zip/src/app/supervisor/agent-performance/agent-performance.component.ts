import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { AgentService } from 'src/app/services/agent.service';
import { AgentPerformance } from 'src/app/models/agent-performance';

@Component({
  selector: 'app-agent-performance',
  templateUrl: './agent-performance.component.html',
  styleUrls: ['./agent-performance.component.scss']
})

export class AgentPerformanceComponent implements OnInit {

  agents: (AgentPerformance & { score:number })[] = [];
  topAgents: (AgentPerformance & { score:number })[] = [];
     navLinks = [
      {label: 'Dashboard', route: '/supervisor-dashboard' },
    { label: 'Parcel Management', route: '/parcel-management' },

    { label: 'Report Generation', route: '/report-generation' }
  ];

  Highcharts: typeof Highcharts = Highcharts;

  chartOptions: Highcharts.Options = {

    chart: { type:'column' },

    title: { text:'Agent Performance' },

    xAxis: {
      categories: []
    },

    yAxis:{
      title:{ text:'Parcel Count' }
    },

    series: [
      {
        type:'column',
        name:'Delivered',
        data:[]
      },
      {
        type:'column',
        name:'In Transit',
        data:[]
      },
      {
        type:'column',
        name:'Picked Up',
        data:[]
      }
    ]

  };


  popupMessage = '';
  showPopup = false;
   showDeletePopup = false;
  selectedAgentId: string = '';

  constructor(private agentService: AgentService) {}

  ngOnInit(): void {
    this.loadAgentPerformance();
  }

  loadAgentPerformance(){

    this.agentService.getAgentPerformance().subscribe({

      next:(data)=>{

        console.log(data);

        this.agents = data.map(a => ({
          ...a,
          score: (a.delivered * 5) + (a.inTransit * 3) + (a.pickedUp * 1)
        }));

        this.agents.sort((a,b)=> b.score - a.score);

        this.topAgents = this.agents.slice(0,3);

        this.updateChart();

      },

      error:()=>{
        this.showMessage("Error loading agent performance");
      }

    });

  }

  updateChart(){

    this.chartOptions = {

      ...this.chartOptions,

      xAxis:{
        categories: this.agents.map(a => a.name)
      },
       yAxis:{
    title:{ text:'Parcel Count' },
    allowDecimals:false,
    tickInterval:1
  },

  plotOptions:{
    column:{
      borderRadius:5
    }
  },

      series:[
        {
          type:'column',
          name:'Delivered',
          data: this.agents.map(a => a.delivered)
        },
        {
          type:'column',
          name:'In Transit',
          data: this.agents.map(a => a.inTransit)
        },
        {
          type:'column',
          name:'Picked Up',
          data: this.agents.map(a => a.pickedUp)
        }
      ]

    };



  }

 openDeletePopup(agentId: string) {
  this.selectedAgentId = agentId;
  this.showDeletePopup = true;
}

confirmDelete() {

  this.agentService.deleteAgent(this.selectedAgentId).subscribe({

    next: (res: any) => {
      this.showDeletePopup = false;
      this.showMessage(res.message);
      this.loadAgentPerformance();
    },

    error: (err) => {
      this.showDeletePopup = false;
      this.showMessage(err.error?.message || "Failed to delete agent");
    }

  });
}

cancelDelete() {
  this.showDeletePopup = false;
}

  showMessage(message:string){
    this.popupMessage = message;
    this.showPopup = true;
  }

  closePopup(){
    this.showPopup = false;
  }

}
