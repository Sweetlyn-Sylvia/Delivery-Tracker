import { Component,OnInit } from '@angular/core';
import {Router} from '@angular/router';

import { ParcelService } from '../../services/parcel.service';
import{SupervisorService} from '../../services/supervisor.service';
import { ParcelDetails } from '../../models/parcel-details';


@Component({
  selector: 'app-parcel-management',
  templateUrl: './parcel-management.component.html',
  styleUrls: ['./parcel-management.component.scss']
})
export class ParcelManagementComponent implements OnInit {


 parcels: ParcelDetails[] = [];

  filters = {
    status: '',
    agentId: '',
    date: ''
  };

  agentList: any[] = [];

  showModal = false;
  selectedParcel: ParcelDetails | null = null;
   navLinks = [
    { label: 'Dashboard', route: '/supervisor-dashboard' },
    { label: 'Agent Performance', route: '/agent-performance' },
    { label: 'Report Generation', route: '/report-generation' }
  ];

  constructor(
    private parcelService: ParcelService,
    private supervisorService: SupervisorService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadParcels();
    this.loadAgents();
  }

  loadAgents() {
    this.supervisorService.getAgents().subscribe({
      next: (res) => this.agentList = res,
      error: (err) => console.error(err)
    });
  }

  loadParcels() {

    this.parcelService.filterParcels({
      status: this.filters.status,
      agentId: this.filters.agentId,
      date: this.filters.date
    }).subscribe({

      next: (data) => {
        this.parcels = data;
      },

      error: (err) => console.error(err)

    });

  }

  openParcelModal(parcelId: string) {

    this.showModal = true;
    this.selectedParcel = null;

    this.parcelService.getParcelById(parcelId).subscribe({

      next: (data) => {
        this.selectedParcel = data;
      },

      error: (err) => console.error(err)

    });

  }

  closeModal() {
    this.showModal = false;
  }

  logout() {
    localStorage.removeItem('supervisorID');
    localStorage.removeItem('supervisorData');
    this.router.navigate(['/supervisor-login']);
  }
  clearFilters() {

  this.filters = {
    status: '',
    agentId: '',
    date: ''
  };

  this.loadParcels();

}

}
