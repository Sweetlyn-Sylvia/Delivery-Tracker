import { Component,OnInit } from '@angular/core';
import { SupervisorService } from '../../services/supervisor.service';
import { UpdateProfileRequest } from 'src/app/models/sup-update-profile';
import { Supervisor } from 'src/app/models/supervisor';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})

export class ProfileComponent implements OnInit {
   navLinks = [
    { label: 'Dashboard', route: '/supervisor-dashboard' },
    { label: 'Parcel Management', route: '/parcel-management' },
    { label: 'Agent Performance', route: '/agent-performance' },
    { label: 'Report Generation', route: '/report-generation' }

  ];


supervisor: Supervisor = {
    supervisorId: '',
    name: '',
    email: '',
    phone: ''
  };

 supervisorId = localStorage.getItem('supervisorID') || '';

  currentPassword: string = '';
  newPassword: string = '';

  popupMessage: string = '';
  showPopup: boolean = false;

  constructor(private supervisorService: SupervisorService) {}

  ngOnInit(): void {
    this.loadProfile();
  }

  loadProfile(): void {

    this.supervisorService.getProfile(this.supervisorId).subscribe({
      next: (data) => {
        this.supervisor = data;
      },
      error: () => {
        this.showMessage("Error loading supervisor profile");
      }
    });

  }

  updateProfile(): void {


    if (this.newPassword && !this.currentPassword) {
      this.showMessage("Enter current password to change password");
      return;
    }


    if (!this.currentPassword && !this.newPassword  ) {
      this.showMessage("Enter current password to update profile");
      return;
    }

    const payload: UpdateProfileRequest = {
      supervisorId: this.supervisorId,
      name: this.supervisor.name,
      email: this.supervisor.email,
      phone: this.supervisor.phone,
      currentPassword: this.currentPassword,
      newPassword: this.newPassword
    };

    this.supervisorService.updateProfile(payload).subscribe({

      next: (res) => {
        this.showMessage(res.message);
        this.currentPassword = '';
        this.newPassword = '';
      },

      error: (err) => {
        this.showMessage(err.error);
      }

    });

  }

  showMessage(message: string) {
    this.popupMessage = message;
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
  }



}
