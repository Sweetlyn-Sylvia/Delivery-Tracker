import { Component, OnInit } from '@angular/core';
import { ReportService } from '../../services/report.service';
import { SupervisorService } from '../../services/supervisor.service';

@Component({
  selector: 'app-report-generation',
  templateUrl: './report-generation.component.html',
  styleUrls: ['./report-generation.component.scss']
})
export class ReportGenerationComponent implements OnInit {

  showRange = false;
  showAgent = false;
  showAgentOption = false;
  showEarnings = false;

  startDate!: string;
  endDate!: string;
  selectedAgent!: string;

  agents: any[] = [];

  navLinks = [
    { label: 'Dashboard', route: '/supervisor-dashboard' },
    { label: 'Parcel Management', route: '/parcel-management' },
    { label: 'Agent Performance', route: '/agent-performance' },

  ];

  constructor(
    private reportService: ReportService,
    private supervisorService: SupervisorService
  ) {}

  ngOnInit() {
    this.loadAgents();
  }

  downloadReport(type: string) {

    let request;

    if (type === 'daily') {
      request = this.reportService.getDailyReport();
    }

    if (type === 'delivered') {
      request = this.reportService.getDeliveredReport();
    }

    if (type === 'pending') {
      request = this.reportService.getPendingReport();
    }

    request?.subscribe(blob => this.saveFile(blob, `${type}-report.pdf`));
  }

  downloadRangeReport() {

    this.reportService
      .getRangeReport(this.startDate, this.endDate)
      .subscribe(blob => this.saveFile(blob, 'range-report.pdf'));

    this.closeRangePopup();
  }

  downloadAgentReport() {

    this.reportService
      .getAgentReport(this.selectedAgent)
      .subscribe(blob =>
        this.saveFile(blob, `agent-report-${this.selectedAgent}.pdf`)
      );

    this.closeAgentPopup();
  }

  private saveFile(blob: Blob, filename: string) {

    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();

    URL.revokeObjectURL(link.href);
  }

  openRangePopup() { this.showRange = true; }


  openAgentPopup() { this.showAgent = true; }


  openEarningsPopup() { this.showEarnings = true; }
  closeAgentPopup() {
  this.showAgent = false;
  this.selectedAgent = '';
}

closeRangePopup() {
  this.showRange = false;
  this.startDate = '';
  this.endDate = '';
}

closeEarningsPopup() {
  this.showEarnings = false;
  this.startDate = '';
  this.endDate = '';
}

  loadAgents() {
    this.supervisorService.getAgents().subscribe({
      next: (res) => {
        this.agents = res;
      },
      error: (err) => console.error(err)
    });
  }



}
