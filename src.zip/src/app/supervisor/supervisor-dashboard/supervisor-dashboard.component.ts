import { Component,OnInit} from '@angular/core';
import{ SupervisorService } from '../../services/supervisor.service';
import { DashboardSummary, NotificationResponse, AssignAgent, Agent } from '../../models/supervisor-login';
import { Router } from '@angular/router';

@Component({
  selector: 'app-supervisor-dashboard',
  templateUrl: './supervisor-dashboard.component.html',
  styleUrls: ['./supervisor-dashboard.component.scss']
})
export class SupervisorDashboardComponent implements OnInit {

  supervisorName = '';

  summary: DashboardSummary = {
    totalParcels: 0,
    deliveredParcels: 0,
    inTransitParcels: 0,
    pickedUpParccels: 0,
    totalAgents: 0,
    todaysEarning: 0
  };

  notifications: NotificationResponse[] = [];

  agents: Agent[] = [];

  showReminderBox = false;
  showAssignBox = false;

  selectedParcelID = '';
  selectedAgentID = '';

  popupMessage = '';
  showPopup = false;

  navLinks = [
    { label: 'Parcel Management', route: '/parcel-management' },


    { label: 'Agent Performance', route: '/agent-performance' },
    { label: 'Report Generation', route: '/report-generation' },
        { label: 'Profile', route: '/supervisor-profile' },

  ];

  constructor(
    private supervisorService: SupervisorService,
    private router: Router
  ) {}

  ngOnInit(): void {

    const stored = localStorage.getItem('supervisorData');

    if (stored) {
      const data = JSON.parse(stored);
      this.supervisorName = data.name;
    }

    this.loadSummary();
    this.loadNotifications();
    this.loadAgents();
  }

  loadSummary() {

    this.supervisorService.getDashboardSummary().subscribe({

      next: (data) => {
        this.summary = data;
      },

      error: () => {
        this.showMessage("Error loading dashboard summary");
      }

    });

  }

  loadNotifications() {

    this.supervisorService.getNotifications().subscribe({

      next: (data) => {
        this.notifications = data;
      },

      error: () => {
        this.showMessage("Error loading notifications");
      }

    });

  }

  loadAgents() {

    this.supervisorService.getAgents().subscribe({

      next: (data) => {
        this.agents = data;
      },

      error: () => {
        this.showMessage("Error loading agents");
      }

    });

  }

  openReminder(parcelID: string) {

    this.selectedParcelID = parcelID;
    this.showReminderBox = true;

  }

  sendReminder() {

    if (!this.selectedAgentID) {
      this.showMessage("Please select an agent");
      return;
    }

    const payload: AssignAgent = {
      parcelId: this.selectedParcelID,
      agentId: this.selectedAgentID
    };

    this.supervisorService.sendReminder(payload).subscribe({

      next: (res) => {

        this.showMessage(res.message);
        this.closeReminder();
        this.loadNotifications();

      },

      error: () => {
        this.showMessage("Error sending reminder");
      }

    });

  }

  closeReminder() {
    this.showReminderBox = false;
    this.selectedAgentID = '';
  }

  openAssignBox(parcelID: string) {

    this.selectedParcelID = parcelID;
    this.showAssignBox = true;

  }

  sendAssign() {

    if (!this.selectedAgentID) {
      this.showMessage("Please select an agent");
      return;
    }

    const payload: AssignAgent = {
      parcelId: this.selectedParcelID,
      agentId: this.selectedAgentID
    };

    this.supervisorService.assignAgent(payload).subscribe({

      next: (res) => {

        this.showMessage(res.message);
        this.closeAssignBox();
        this.loadNotifications();

      },

      error: () => {
        this.showMessage("Error assigning agent");
      }

    });

  }

  closeAssignBox() {
    this.showAssignBox = false;
    this.selectedAgentID = '';
  }

  logout() {
    localStorage.removeItem('supervisorID');
    localStorage.removeItem('supervisorData');
    window.location.href = '/supervisor-login';
  }

  showMessage(msg: string) {
    this.popupMessage = msg;
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
  }

}
