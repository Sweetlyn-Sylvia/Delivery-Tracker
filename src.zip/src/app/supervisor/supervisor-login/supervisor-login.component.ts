import { Component } from '@angular/core';
import { SupervisorService } from '../../services/supervisor.service';
import { Router } from '@angular/router';
import { SupervisorLoginResponse } from '../../models/supervisor-login';
import { SupervisorLogin } from '../../models/supervisor-login';


@Component({
  selector: 'app-supervisor-login',
  templateUrl: './supervisor-login.component.html',
  styleUrls: ['./supervisor-login.component.scss']
})
export class SupervisorLoginComponent {
  supervisor: SupervisorLogin = {
    SupervisorId: '',
    Password: ''
  };

    navLinks = [
    { label: 'Home', route: '/' },
    { label: 'Agent Portal', route: '/agent-login' }
  ];

  popupMessage = '';
  showPopup = false;

  constructor(
    private supervisorService: SupervisorService,
    private router: Router
  ) {}

 onLogin() {

  if (!this.supervisor.SupervisorId || !this.supervisor.Password) {
    this.showMessage("Please enter Supervisor ID and Password");
    return;
  }

  this.supervisorService.login(this.supervisor).subscribe({

    next: (res: SupervisorLoginResponse) => {

      if (res.message === "Login Successful") {

        localStorage.setItem('supervisorID', this.supervisor.SupervisorId);

        this.supervisorService
          .getSupervisorById(this.supervisor.SupervisorId)
          .subscribe({

            next: (data) => {

              localStorage.setItem(
                'supervisorData',
                JSON.stringify(data)
              );

              this.showMessage("Login Successful");

              setTimeout(() => {
                this.router.navigate(['/supervisor-dashboard']);
              }, 1200);

            }

          });

      }
      else {
        this.showMessage(res.message);
      }

    },

    error: () => {
      this.showMessage("Error during login");
    }

  });
}
  showMessage(msg: string) {
    this.popupMessage = msg;
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
  }

}


